
"use strict";

let input_point = require('./input_point.js');
let output_point = require('./output_point.js');

module.exports = {
  input_point: input_point,
  output_point: output_point,
};
